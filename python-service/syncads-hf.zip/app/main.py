"""
SyncAds Python Service - COMPLETO
Todos os modais: Images, PDF, Websites, Scraping, Automation
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import (
    images,
    pdf,
    modules,
    scraping,
    automation,
    webhooks,
    omnibrain,
    graphql_router,
    extension
)

app = FastAPI(
    title="SyncAds Complete Service",
    description="Serviço completo com AI, automação, processamento de imagens/PDF, scraping e mais",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# INCLUIR TODOS OS ROUTERS
# =====================================================
app.include_router(automation.router, prefix="/automation", tags=["Automation"])
app.include_router(images.router, prefix="/images", tags=["Images"])
app.include_router(pdf.router, prefix="/pdf", tags=["PDF"])
app.include_router(modules.router, prefix="/modules", tags=["Modules"])
app.include_router(scraping.router, prefix="/scraping", tags=["Scraping"])
app.include_router(webhooks.router, prefix="/webhooks", tags=["Webhooks"])
app.include_router(omnibrain.router, prefix="/omnibrain", tags=["OmniBrain"])
app.include_router(graphql_router.router, prefix="/graphql", tags=["GraphQL"])
app.include_router(extension.router, prefix="/extension", tags=["Extension"])

# =====================================================
# ROOT ENDPOINTS
# =====================================================
@app.get("/")
async def root():
    return {
        "status": "ok",
        "service": "SyncAds Complete Service",
        "version": "2.0.0",
        "endpoints": {
            "/automation": "Browser automation (Playwright)",
            "/images": "Image generation & processing",
            "/pdf": "PDF creation & manipulation",
            "/modules": "Website builder & modules",
            "/scraping": "Web scraping",
            "/webhooks": "Webhook handlers",
            "/omnibrain": "AI OmniBrain",
            "/graphql": "GraphQL API",
            "/extension": "Chrome extension endpoints"
        }
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "complete"}

# Run
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
